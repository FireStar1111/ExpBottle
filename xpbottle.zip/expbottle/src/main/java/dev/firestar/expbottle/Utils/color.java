package dev.firestar.expbottle.Utils;

import org.bukkit.ChatColor;

public class color {

    public static String format(String input){
        return ChatColor.translateAlternateColorCodes('&', input);
    }

}
